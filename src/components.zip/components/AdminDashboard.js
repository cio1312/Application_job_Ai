import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components';

const AdminDashboard = () => {
  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));
    if (!user || user.role !== 'ADMIN') {
      navigate('/login');
    }
  }, [navigate]);

  const handleAddNewJobClick = () => {
    navigate('/admin-dashboard/add-job');
  };

  const handleJobListClick = () => {
    navigate('/admin-dashboard/job-list');
  };

  const handleViewApplicationsClick = () => {
    navigate('/admin-dashboard/view-applications');
  };

  return (
    <DashboardContainer>
      <Title>Admin Dashboard</Title>
      <ButtonContainer>
        <StyledButton onClick={handleAddNewJobClick}>Add New Job</StyledButton>
        <StyledButton onClick={handleJobListClick}>View Job List</StyledButton>
        <StyledButton onClick={handleViewApplicationsClick}>View Applications</StyledButton>
      </ButtonContainer>
    </DashboardContainer>
  );
};

const DashboardContainer = styled.div`
  background-color: #2c3e50;  /* Dark red background */
  color: white;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px;
`;

const Title = styled.h1`
  font-size: 3rem;
  margin-bottom: 40px;
  color: #ecf0f1;
`;

const ButtonContainer = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const StyledButton = styled.button`
  background-color: #e74c3c;
  color: white;
  padding: 12px 25px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1.2rem;
  transition: background-color 0.3s;
  
  &:hover {
    background-color: #c0392b;
  }
`;

export default AdminDashboard;
