// src/components/Navigation.js
import React from 'react';
import { Link } from 'react-router-dom';

const Navigation = () => {
  return (
    <div className="navigation-container">
      <nav className="navigation">
        <ul className="navigation-tabs">
          <li>
            <Link to="/profile" className="tab">Profile</Link>
          </li>
          <li>
            <Link to="/jobs" className="tab">Job Listings</Link>
          </li>
        </ul>
      </nav>

      <style>
        {`
        /* General Container Styling */
        .navigation-container {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
          background-color: #1e1e1e; /* Dark gray background */
        }

        /* Navigation Styling */
        .navigation {
          text-align: center;
        }

        /* Tabs Styling */
        .navigation-tabs {
          list-style: none;
          padding: 0;
          margin: 0;
          display: flex;
          gap: 20px; /* Spacing between tabs */
        }

        .tab {
          display: inline-block;
          padding: 15px 30px;
          font-size: 1.2rem;
          font-weight: bold;
          color: white;
          text-decoration: none;
          background: linear-gradient(145deg, #202020, #2a2a2a); /* Subtle 3D effect */
          border: 2px solid #00b4d8; /* Glowing blue border */
          border-radius: 8px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.6), 0 0 10px rgba(0, 180, 216, 0.6); /* Glow effect */
          transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .tab:hover {
          transform: translateY(-4px); /* Lift effect */
          box-shadow: 0 6px 10px rgba(0, 0, 0, 0.8), 0 0 15px rgba(0, 180, 216, 0.9); /* Stronger glow */
        }

        .tab:active {
          transform: translateY(2px); /* Pressed-down effect */
          box-shadow: 0 2px 4px rgba(0, 0, 0, 0.5), 0 0 8px rgba(0, 180, 216, 0.6);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
          .tab {
            font-size: 1rem;
            padding: 12px 24px;
          }
        }
        `}
      </style>
    </div>
  );
};

export default Navigation;
