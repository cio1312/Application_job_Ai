import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { useNavigate } from 'react-router-dom';

const JobList = () => {
  const [jobs, setJobs] = useState([]);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const user = JSON.parse(localStorage.getItem('user'));

    if (!user || user.role !== 'ADMIN') {
      window.location.href = '/login'; // Or use navigate if using react-router
      return;
    }

    const adminId = user.adminId;

    if (!adminId) {
      setError("Admin ID is missing.");
      return;
    }

    fetch(`http://localhost:8080/api/jobs/admin/${adminId}`)
      .then((response) => {
        if (!response.ok) {
          throw new Error('Failed to fetch jobs');
        }
        return response.json();
      })
      .then((data) => setJobs(data))
      .catch((err) => setError(err.message));
  }, []);

  // Toggle the job's active status on the UI (using 'isActive' instead of 'active')
  const toggleJobStatus = (jobId) => {
    setJobs((prevJobs) => {
      const updatedJobs = prevJobs.map((job) =>
        job.id === jobId ? { ...job, isActive: !job.isActive } : job // Using 'isActive' from backend
      );
      console.log('Updated job:', updatedJobs.find((job) => job.id === jobId));
      return updatedJobs;
    });
  };

  // Save jobs to the backend
  const saveJobs = () => {
    const updatedJobs = jobs.filter((job) => job.isActive !== undefined); // Checking 'isActive'

    if (updatedJobs.length === 0) {
      alert("No changes to save.");
      return;
    }

    console.log('Saving jobs:', updatedJobs);

    updatedJobs.forEach((job) => {
      console.log(`Job ID: ${job.id}, isActive: ${job.isActive}`); // Using 'isActive' instead of 'active'
      fetch(`http://localhost:8080/api/jobs/${job.id}/status`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          isActive: job.isActive, // Sending the updated isActive status
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.message === 'Job updated successfully') {
            console.log(`Job ${job.id} updated successfully`);
          } else {
            console.error(`Failed to update job ${job.id}`);
          }
        })
        .catch((err) => {
          console.error('Error updating job:', err);
        });
    });
  };

  // Handle the back button click event
  const handleBackClick = () => {
    navigate(-1); // This takes the user back to the previous page in the browser history
  };

  return (
    <Container>
      <Title>Job List</Title>
      {error && <ErrorMessage>{error}</ErrorMessage>}
      {jobs.length === 0 ? (
        <NoJobsMessage>No jobs available.</NoJobsMessage>
      ) : (
        <JobCards>
          {jobs.map((job) => (
            <JobCard key={job.id}>
              <JobHeader>
                <h3>{job.companyName}</h3>
                <JobStatus>
                  <button onClick={() => toggleJobStatus(job.id)}>
                    {job.isActive ? 'Deactivate' : 'Activate'} {/* Using 'isActive' from backend */}
                  </button>
                </JobStatus>
              </JobHeader>
              <JobDetails>
                <p><strong>Description:</strong> {job.companyDescription}</p>
                <p><strong>Location:</strong> {job.location}</p>
                <p><strong>Company Theme:</strong> {job.companyTheme}</p>
                <p><strong>Company Policies:</strong> {job.companyPolicies}</p>
                <p><strong>About:</strong> {job.about}</p>
                <p><strong>Contact:</strong> {job.contact}</p>
              </JobDetails>
            </JobCard>
          ))}
        </JobCards>
      )}
      <SaveButton onClick={saveJobs}>Save Changes</SaveButton>
      <BackButton onClick={handleBackClick}>Back</BackButton>
    </Container>
  );
};

// Styling for the back button
const BackButton = styled.button`
  background-color: #95a5a6;
  color: white;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1.2rem;
  margin-top: 20px;
  transition: background-color 0.3s;
  &:hover {
    background-color: #7f8c8d;
  }
`;

const Container = styled.div`
  background-color: #1c1c1c;
  color: white;
  min-height: 100vh;
  padding: 40px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

const Title = styled.h2`
  font-size: 2.5rem;
  margin-bottom: 20px;
  color: #ecf0f1;
`;

const ErrorMessage = styled.p`
  color: red;
  font-weight: bold;
`;

const NoJobsMessage = styled.p`
  font-size: 1.5rem;
  color: #7f8c8d;
`;

const JobCards = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  width: 100%;
  max-width: 1200px;
`;

const JobCard = styled.div`
  background-color: #34495e;
  border-radius: 10px;
  padding: 20px;
  box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
  transition: transform 0.2s ease-in-out;
  &:hover {
    transform: translateY(-5px);
  }
`;

const JobHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
`;

const JobStatus = styled.div`
  button {
    background-color: #e74c3c;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s;
    &:hover {
      background-color: #c0392b;
    }
  }
`;

const JobDetails = styled.div`
  font-size: 1rem;
  line-height: 1.5;
  color: #ecf0f1;
`;

const SaveButton = styled.button`
  background-color: #3498db;
  color: white;
  padding: 12px 25px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 1.2rem;
  margin-top: 30px;
  transition: background-color 0.3s;
  &:hover {
    background-color: #2980b9;
  }
`;

export default JobList;
