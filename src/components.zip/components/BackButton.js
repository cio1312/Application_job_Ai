import React from 'react';
import { useNavigate } from 'react-router-dom';

const BackButton = () => {
  const navigate = useNavigate();

  return (
    <button className="btn-back" onClick={() => navigate(-1)}>
      Back
    </button>
  );
};

export default BackButton;

<style>
  {`
  .btn-back {
    background-color: #38b2ac; /* Elegant green shade */
    color: white;
    border: none;
    padding: 10px 20px;
    font-size: 1rem;
    font-weight: bold;
    border-radius: 8px;
    cursor: pointer;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    transition: all 0.3s ease;
    margin: 10px;
  }

  .btn-back:hover {
    background-color: #2c7a7b; /* Darker green for hover effect */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2);
    transform: translateY(-2px); /* Slight elevation on hover */
  }

  .btn-back:active {
    background-color: #225e5f; /* Even darker green when clicked */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
    transform: translateY(0); /* Reset elevation on click */
  }
  `}
</style>
